package com.company;

public interface Functionable {

     void add();
    void subtract();
    void multiply();
    void divide();
    void findOperator();
}
